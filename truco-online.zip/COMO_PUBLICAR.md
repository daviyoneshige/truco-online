# 🃏 Truco Paulista Online — Guia de Publicação

## O que você tem nesta pasta

```
truco-online/
├── server.js        ← o servidor (Node.js + Socket.io)
├── package.json     ← lista de dependências do servidor
└── public/
    └── index.html   ← o jogo (abre no navegador)
```

## Como publicar no Railway (grátis, 10 minutos)

### Passo 1 — Criar conta no GitHub
Acesse https://github.com e crie uma conta gratuita.
O GitHub é onde você vai guardar o código online.

### Passo 2 — Criar um repositório
Clique em "New repository", dê o nome "truco-online",
deixe como "Public" e clique em "Create repository".

### Passo 3 — Subir os arquivos
Na página do repositório, clique em "uploading an existing file".
Arraste os três arquivos/pasta:
- server.js
- package.json
- a pasta public/ com o index.html dentro

Clique em "Commit changes".

### Passo 4 — Criar conta no Railway
Acesse https://railway.app e clique em "Login with GitHub".
Autorize o Railway a acessar sua conta.

### Passo 5 — Criar o projeto
Clique em "New Project" → "Deploy from GitHub repo".
Selecione o repositório "truco-online".
O Railway vai detectar automaticamente que é Node.js.

### Passo 6 — Configurar a porta
Nas configurações do projeto, vá em "Variables" e adicione:
  PORT = 3000

### Passo 7 — Pegar o endereço
Após o deploy (leva 1-2 minutos), clique em "Generate Domain".
Você vai receber um endereço tipo:
  truco-online.up.railway.app

Esse é o endereço do seu jogo online! Qualquer pessoa
no mundo pode abrir esse link e jogar contra você.

## Como jogar online com um amigo

1. Os dois abrem o mesmo endereço no navegador
2. Os dois criam contas e fazem login
3. Os dois clicam em "1v1 Online"
4. O sistema conecta vocês automaticamente

## Observações importantes

- O plano gratuito do Railway tem 500 horas por mês.
  Para um jogo pessoal, é mais do que suficiente.
- Se o servidor "dormir" por inatividade, a primeira
  conexão pode demorar uns 30 segundos para "acordar".
- Para uso sério com muitos jogadores, considere o
  plano pago (US$ 5/mês).
